name = input()
a = float(input())
b = float(input())
total = a+(b*15)/100
print("TOTAL = R$ %0.2f"%total)
