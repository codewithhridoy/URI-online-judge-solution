for i in range(10):
    n=int(input())
    if(n< 1):
        n = 1
    print("X[%d] = %d" % (i, n))