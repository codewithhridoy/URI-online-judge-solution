n = int(input())
total = (4/3.0*3.14159*n*n*n)
print("VOLUME = %0.3f"%total)