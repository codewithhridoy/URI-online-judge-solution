n=int(input())
print("{} minutos".format(n*2))