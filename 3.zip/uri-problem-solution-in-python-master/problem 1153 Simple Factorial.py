n=int(input())
s=1
for i in range(n,1,-1):
    s = s*i
print(s)