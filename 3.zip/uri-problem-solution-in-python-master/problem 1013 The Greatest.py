a,b,c=list(map(int,input().split()))
print("{} eh o maior".format(max(a,b,c)))