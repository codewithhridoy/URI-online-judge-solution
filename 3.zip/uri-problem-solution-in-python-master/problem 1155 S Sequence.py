s=0
for i in range(1,101):
    m=1/i
    s=s+m
print("%0.2f"%s)