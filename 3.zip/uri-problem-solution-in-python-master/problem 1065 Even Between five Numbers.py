count=0
for i in range(5):
    n = float(input())
    if(n%2==0):
        count=count+1
print("{} valores pares".format(count))