count=0
for i in range(1,7):
    n = float(input())
    if(n>0):
        count=count+1
print("{} valores positivos".format(count))