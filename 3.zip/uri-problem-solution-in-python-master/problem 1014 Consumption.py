a=int(input())
b=float(input())
total=a/b
print("%0.3f km/l"%total)