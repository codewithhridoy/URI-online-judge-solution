a=int(input())
b=int(input())
print("%0.3f"%((a*b)/12.0))