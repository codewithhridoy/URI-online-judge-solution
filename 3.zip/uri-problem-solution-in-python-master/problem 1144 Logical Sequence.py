n=int(input())
for i in range(1,n+1):
    c = i*i
    d= i*i*i
    print("{} {} {}".format(i,c,d))
    e=c+1
    f=d+1
    print("{} {} {}".format(i,e,f))