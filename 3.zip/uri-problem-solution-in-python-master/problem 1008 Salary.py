a= int(input())
b= int(input())
c=float(input())
print("NUMBER =",a)
mult=b*c
print("SALARY = U$ %0.2f"%mult)
