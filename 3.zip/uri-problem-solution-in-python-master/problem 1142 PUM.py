n = int(input())
c = 1
for i in range(n):
    print("%d %d %d PUM" %(c,c+1,c+2))
    c += 4