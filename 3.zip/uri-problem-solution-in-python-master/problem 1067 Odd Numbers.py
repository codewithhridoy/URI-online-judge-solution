n = int(input())
for i in range(n+1):
    if(i%2==1):
        print(i)