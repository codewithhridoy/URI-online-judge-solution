for i in range(1,10,2):
    for j in range(7,4,-1):
        print("I={} J={}".format(i,j))