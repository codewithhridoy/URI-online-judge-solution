a=float(input())
b=int(input())
print("PROD =",int(a*b))