n = int(input())
print("{}:{}:{}".format(int(n/3600),int(n%3600/60),int(n%60)))