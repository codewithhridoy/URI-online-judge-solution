j,i=65,-2
for I in range (1,14):
    J= j-5
    I=i+3
    print('I=%d J=%d' %(I,J))
    j=J
    i=I