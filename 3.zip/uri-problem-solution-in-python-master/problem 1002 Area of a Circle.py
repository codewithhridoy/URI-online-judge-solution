raio = float(input())
area = (raio * raio) * 3.14159
print("A=%0.4f" %area)