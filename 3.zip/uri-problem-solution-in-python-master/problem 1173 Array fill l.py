n= int(input())
print("N[%d] = %d" %(0,n))
for i in range(1,10):
    n *= 2
    print("N[%d] = %d" %(i,n))