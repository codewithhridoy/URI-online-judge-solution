n=int(input())
for i in range(n):
    name=input()
    sum = len(name)
    print("%0.2f"%(sum/100.0))