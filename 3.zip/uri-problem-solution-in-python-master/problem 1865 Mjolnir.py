for i in range(int(input(""))):
    print("Y" if input("").split()[0].lower() == "thor" else "N")