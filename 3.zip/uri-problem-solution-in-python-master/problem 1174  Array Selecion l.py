for i in range(100):
    n = float(input())
    if (n <= 10):
        print("A[%d] = %.1f" % (i, n))