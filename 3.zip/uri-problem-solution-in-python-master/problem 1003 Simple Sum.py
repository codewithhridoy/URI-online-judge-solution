a=int(input())
b=int(input())
print("SOMA =",a+b)