#include <iostream>
 
using namespace std;
 
int main() {
 
    long long x;
    cin>>x;
    cout<<x-2<<endl;
 
    return 0;
}
