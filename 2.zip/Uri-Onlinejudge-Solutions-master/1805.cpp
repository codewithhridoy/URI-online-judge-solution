#include <iostream>
#include <stdio.h>

using namespace std;

int main (){

	long long int soma = 0;
	long long int a,b;

	cin >> a >> b;

	soma = (a + b) * (b-a+1)/2;

	cout << soma << endl;


}
