#include <iostream>
 
using namespace std;
 
int main() {
     int t;
     cin>>t;
     for(int i=1;i<=t;i++)
     {
         cout<<"Ho";
         if(i==t)
         cout<<"!\n";
         else
         cout<<" ";
     }
 
    return 0;
}
