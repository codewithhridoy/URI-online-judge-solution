#include<iostream>
using namespace std;
int main()
{
    int X;
    double Y;
    cin>>X>>Y;
    Y=X/Y;
    printf("%.3lf km/l\n",Y);
    return 0;
}
