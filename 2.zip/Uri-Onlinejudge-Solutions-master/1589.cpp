#include<iostream>
using namespace std;
int main()
{
    int a,b,t;
    cin>>t;
    while(t>0)
    {
        cin>>a>>b;
        cout<<a+b<<endl;
        t--;
    }
    return 0;
}
