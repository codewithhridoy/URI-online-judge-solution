#include <iostream>
 
using namespace std;
 
int main() {
 
    int t;
    cin>>t;
    for(int i=1;i<=t;i++)
    cout<<i<<" "<<i*i<<" "<<i*i*i<<endl;
 
    return 0;
}
