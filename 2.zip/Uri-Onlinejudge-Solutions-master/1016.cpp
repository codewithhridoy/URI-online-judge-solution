#include <iostream>
 
using namespace std;
 
int main() {
 
    /**
     * Escreva a sua solução aqui
     * Code your solution here
     * Escriba su solución aquí
     */
     int a;
     cin>>a;
     a=a*2;
     cout<<a<<" minutos\n";
 
    return 0;
}
