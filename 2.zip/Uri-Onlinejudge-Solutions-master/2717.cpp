#include <iostream>
#include<stdio.h>
#include<math.h>
#include<algorithm>
#include<stack>
#include<queue>
#include<set>
#include<map>
#include<vector>
#include<math.h>
#include<string>
#include<list>

using namespace std;

#define ll long long
#define input scanf
#define output printf 
#define Loop while
#define echo cout
#define ret return
#define MAX 999999999999999999
#define MIN 0
int main(int argc, char** argv) {
	
	//freopen("c.txt","w",stdout);
	string str;
	int n;
	cin>>n;
	int a,b;
	cin>>a>>b;
	if(a+b<=n)
	printf("Farei hoje!\n");
	else
	printf("Deixa para amanha!\n");
	ret 0;
}
