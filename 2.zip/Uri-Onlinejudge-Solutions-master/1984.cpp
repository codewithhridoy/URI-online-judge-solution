#include <iostream>
#include<string> 
using namespace std;
 
int main() {
 
    /**
     * Escreva a sua solução aqui
     * Code your solution here
     * Escriba su solución aquí
     */
     string str;
     cin>>str;
     for(int i=str.length()-1;i>=0;i--)
     cout<<str[i];
     cout<<endl;
 
    return 0;
}
