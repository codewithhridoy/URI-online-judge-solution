#include <iostream>
#include<string>
using namespace std;
 
int main() {
 
    string s="LIFE IS NOT A PROBLEM TO BE SOLVED";
    int a;
    cin>>a;
    for(int i=0;i<a;i++)
    cout<<s[i];
    cout<<endl;
 
    return 0;
}
