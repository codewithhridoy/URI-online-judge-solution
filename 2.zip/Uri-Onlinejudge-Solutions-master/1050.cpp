#include <iostream>
 
using namespace std;
 
int main() {
 
     int number;
     cin>>number;
     if(number==61)
     cout<<"Brasilia\n";
     else if(number==71)
     cout<<"Salvador\n";
     else if(number==11)
     cout<<"Sao Paulo\n";
     else if(number==21)
     cout<<"Rio de Janeiro\n";
     else if(number==32)
     cout<<"Juiz de Fora\n";
     else if(number==19)
     cout<<"Campinas\n";
     else if(number==27)
     cout<<"Vitoria\n";
     else if(number==31)
     cout<<"Belo Horizonte\n";
     else
     cout<<"DDD nao cadastrado\n";
     
 
    return 0;
}
