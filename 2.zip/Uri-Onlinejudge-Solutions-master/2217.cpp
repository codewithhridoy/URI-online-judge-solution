#include<bits/stdc++.h>
using namespace std;
int main()
{
    int t;
    cin>>t;
    while(t--)
    {
        int n;
        cin>>n;
        if(n%2==0)
        {
            cout<<"1\n";
        }
        else
        {
            cout<<"9\n";
        }
    }
    return 0;
}
