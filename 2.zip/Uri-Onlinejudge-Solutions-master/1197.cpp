#include <iostream>
 
using namespace std;
 
int main() {

     int a,b;
     while((scanf("%d%d",&a,&b))!=EOF)
     {
         cout<<2*a*b<<endl;
     }
 
    return 0;
}
