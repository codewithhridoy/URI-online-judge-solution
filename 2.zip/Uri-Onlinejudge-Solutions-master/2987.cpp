#include <iostream>
 
using namespace std;
 
int main() {
 
    /**
     * Escreva a sua solução aqui
     * Code your solution here
     * Escriba su solución aquí
     */
     char c;
     
     cin>>c;
     cout<<c-64<<endl;
 
    return 0;
}
