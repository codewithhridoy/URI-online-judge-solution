#include<iostream>
using namespace std;
int main()
{
    double r;
    cin>>r;
    r=(4/3.0)*r*r*r*3.14159;
    printf("VOLUME = %.3lf\n",r);
    return 0;
}
