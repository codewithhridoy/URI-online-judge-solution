#include<stdio.h>
#include<iostream>
using namespace std;
int main()
{
    double x,y;
    cin>>x>>y;
    y=x/y;
    printf("%.2lf\n",y);
    return 0;
}
