#include<bits/stdc++.h>

using namespace std;

typedef long long ll;
#define INF 99999999
int main()
{
    double a,b;
    cin>>a>>b;
    double r=pow(a,3);
    a=  1.333333333 * (3.1415*r);
    int g=b/a;
    cout<<g<<'\n';
}
