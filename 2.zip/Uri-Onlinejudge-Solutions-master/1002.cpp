#include <iostream>
 
using namespace std;
 
int main() {

     double x;
     cin>>x;
     x=x*x*3.14159;
     printf("A=%.4lf\n",x);
     
 
    return 0;
}
