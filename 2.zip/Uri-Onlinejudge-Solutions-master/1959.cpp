#include <iostream>
 
using namespace std;
 
int main() {
     long long x,y;
     cin>>x>>y;
     x=x*y;cout<<x<<endl;
 
    return 0;
}
