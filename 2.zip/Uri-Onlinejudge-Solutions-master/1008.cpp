#include<iostream>
using namespace std;
int main()
{
    int a,b;
    float c;
    cin>>a>>b>>c;
    float d;
    d=b*c;
    cout<<"NUMBER = "<<a<<endl;
    printf("SALARY = U$ %.2f\n",d);
    return 0;
}
