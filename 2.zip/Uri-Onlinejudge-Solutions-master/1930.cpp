#include <iostream>
 
using namespace std;
 
int main() {
 
     int a,b,c,d;
     cin>>a>>b>>c>>d;
     a=a+b+c+d-3;
     cout<<a<<endl;
 
    return 0;
}
