#include <iostream>
 
using namespace std;
 
int main() {
 
    int t;
    cin>>t;
    while(t-->0)
    {
        string g;
        cin>>g;
    }
    cout<<"Ciencia da Computacao\n";
 
    return 0;
}
