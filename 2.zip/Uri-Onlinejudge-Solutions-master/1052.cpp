#include <iostream>
 
using namespace std;
 
int main() {
 
    int number;
    cin>>number;
    if(number==1)
    cout<<"January\n";
    else if(number==2)
    cout<<"February\n";
    else if(number==3)
    cout<<"March\n";
    else if(number==4)
    cout<<"April\n";
    else if(number==5)
    cout<<"May\n";
    else if(number==6)
    cout<<"June\n";
    else if(number==7)
    cout<<"July\n";
    else if(number==8)
    cout<<"August\n";
    else if(number==9)
    cout<<"September\n";
    else if(number==10)
    cout<<"October\n";
    else if(number==11)
    cout<<"November\n";
    else if(number==12)
    cout<<"December\n";
 
    return 0;
}
