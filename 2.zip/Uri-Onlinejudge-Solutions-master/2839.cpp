#include <iostream>

using namespace std;

int main() {

     long long n;
     while(cin>>n)
     cout<<n+1<<endl;
    return 0;
}
