#include<bits/stdc++.h>
using namespace std;
int main()
{
    int n;
    cin>>n;
    long long tri;
    tri=pow(3,n);
    cout<<tri<<endl;
    return 0;
}
