import java.util.Scanner;
class Main{
    public static void main(String args[])
    {
        int a,b;
        Scanner sc=new Scanner(System.in);
        a=sc.nextInt();
        b=sc.nextInt();
        int c=a+b;
        System.out.println("X = "+c);
    }
}
