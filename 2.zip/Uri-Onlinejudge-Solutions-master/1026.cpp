 #include<bits/stdc++.h>
 using namespace std;
 int main()
 {
     long long x,y;
     while(cin>>x>>y)
     {
         long long z;
         z=x^y;
         cout<<z<<endl;
     }
     return 0;
 }
