import java.util.*;
public class Main{
  public static void main(String args[]){
      Scanner sc=new Scanner(System.in);
      while(sc.hasNext()){
         int number;
         number=sc.nextInt();
         sc.next();
         while(number>0){
           String id1;
           id1=sc.nextLine();
           number--;
           System.out.println("I am Toorg!");
         }
     }
   }
}
           
