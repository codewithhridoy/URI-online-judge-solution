#include <iostream>
 
using namespace std;
 
int main() 
{
    int a,b;
    cin>>a>>b;
    a=a*b;
    cout<<"PROD = "<<a<<endl;
    return 0;
}
