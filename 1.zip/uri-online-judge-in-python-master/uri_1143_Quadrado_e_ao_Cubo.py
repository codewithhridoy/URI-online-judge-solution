n = int(input())
c = 1

for i in range(n):
    print("%d %d %d" %(c,c**2,c**3))
    c += 1