X = input()
Y = input()

X = int(X)
Y = float(Y)

CONSUMO = X/Y

print("{:.3f} km/l".format(CONSUMO))