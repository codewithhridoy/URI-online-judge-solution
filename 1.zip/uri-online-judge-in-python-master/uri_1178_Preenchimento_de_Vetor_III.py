valor = float(input())
for i in range(0,100):
    print("N[%d] = %.4f" %(i,valor))
    valor /= 2.0