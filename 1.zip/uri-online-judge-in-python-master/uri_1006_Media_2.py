A = input()
B = input()
C = input()
MEDIA = ((2.0 * float(A)) + (3.0 * float(B))+ (5.0 * float(C))) / 10
print('MEDIA = {:.1f}'.format(MEDIA))