valor = int(input())

for i in range(valor+1):
    if(i%2 != 0):
        print(i)