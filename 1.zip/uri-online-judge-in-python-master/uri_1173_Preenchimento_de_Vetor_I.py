valor = int(input())
print("N[%d] = %d" %(0,valor))
for i in range(1,10):    
    valor *= 2
    print("N[%d] = %d" %(i,valor))