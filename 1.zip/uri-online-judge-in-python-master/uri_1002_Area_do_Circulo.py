raio = input()
area = 3.14159 * (float(raio) * float(raio))
print('A={:.4f}'.format(area))