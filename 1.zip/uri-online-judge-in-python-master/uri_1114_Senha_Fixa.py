while True:
    valor = int(input())
    if(valor == 2002):
        print("Acesso Permitido")
        break
    print("Senha Invalida")