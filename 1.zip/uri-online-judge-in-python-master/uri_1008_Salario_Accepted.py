num = int(input())
hrs = int(input())
vl = float(input())

salario = vl * hrs

print("NUMBER = %d\nSALARY = U$ %.2f" %(num,salario))