soma = 1
tmp = 2;
count = 3
while(count < 40):
    soma += float(count)/float(tmp)
    tmp *= 2
    count += 2

print("%.2f" %soma)