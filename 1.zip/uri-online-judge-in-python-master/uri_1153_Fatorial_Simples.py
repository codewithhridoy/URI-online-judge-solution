n = int(input())
r = 1

for x in range(1,n+1):
    r = x * r

print(r)