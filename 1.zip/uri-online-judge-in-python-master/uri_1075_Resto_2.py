valor = int(input())

for i in range(10000):
    if(i%valor == 2):
        print(i)