while True:
    L, R = list(map(int,input().split()))
    if L+R == 0:
        break
    print(L+R)
