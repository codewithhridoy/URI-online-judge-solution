for i in range(100):    
    valor = float(input())
    if(valor <= 10):
        print("A[%d] = %.1f" %(i,valor))