vl = int(input())

tempo = vl*2

print("{:d} minutos".format(tempo))