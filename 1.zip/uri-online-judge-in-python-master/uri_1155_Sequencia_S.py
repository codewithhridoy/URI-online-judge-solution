soma = 0

for i in range(1,101):
    soma += 1/float(i)

print("%.2f" %soma)