valor = int(input())

for i in range(1,11):
    print("%d x %d = %d" %(i,valor,valor*i))