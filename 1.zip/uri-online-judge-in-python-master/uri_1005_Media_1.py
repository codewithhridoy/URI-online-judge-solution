A = input()
B = input()
MEDIA = ((3.5 * float(A)) + (7.5 * float(B))) / 11
print('MEDIA = {:.5f}'.format(MEDIA))