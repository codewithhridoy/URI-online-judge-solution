i = 1
j = 60

while(j>=0):
    print("I=%d J=%d" %(i,j))
    i += 3
    j += -5