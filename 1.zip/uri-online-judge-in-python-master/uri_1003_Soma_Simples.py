A = input()
B = input()
SOMA = int(A) + int(B)
print('SOMA = {}'.format(SOMA))