for i in range(101):
    if(i%2 == 0 and i > 0):
        print(i)