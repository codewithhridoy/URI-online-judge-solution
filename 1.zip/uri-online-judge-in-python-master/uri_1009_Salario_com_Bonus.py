nome = input()
salario = float(input())
vendas = float(input())

resultado = (vendas * 0.15) + salario

print("TOTAL = R$ %.2f" %resultado)