A = input()
B = input()
PROD  = int(A) * int(B)
print('PROD = {}'.format(PROD))