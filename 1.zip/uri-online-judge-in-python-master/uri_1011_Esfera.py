R = input()
VOLUME = ((4.0/3) * 3.14159 * (float(R)*(float(R)*float(R))))
print('VOLUME = {:.3f}'.format(VOLUME))