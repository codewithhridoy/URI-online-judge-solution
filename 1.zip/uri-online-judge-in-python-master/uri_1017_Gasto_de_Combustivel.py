tempo = int(input())
velocidade = int(input())

litros = (velocidade * tempo) / 12

print("%.3f" %litros)