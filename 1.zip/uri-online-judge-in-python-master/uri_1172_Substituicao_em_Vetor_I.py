for i in range(10):
    valor = int(input())
    if(valor < 1):
        valor = 1
    print("X[%d] = %d" %(i,valor))