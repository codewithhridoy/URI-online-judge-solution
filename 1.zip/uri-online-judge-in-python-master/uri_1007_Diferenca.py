A = input()
B = input()
C = input()
D = input()

DIFERENCA = (int(A) * int(B) - int(C) * int(D))

print('DIFERENCA = {}'.format(DIFERENCA))