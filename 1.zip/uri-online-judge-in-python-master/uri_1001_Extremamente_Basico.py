A = input()
B = input()
X = int(A) + int(B)
print('X = {}'.format(X))